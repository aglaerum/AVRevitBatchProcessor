# -*- coding: utf-8 -*-


import AVFunksjoner
import AVPathsAndSettings as avps
from script_util import Output


AVFunksjoner.reactivate_all_addins(avps.addin_deactivate_foldername, Output)
