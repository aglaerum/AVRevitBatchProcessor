# -*- coding: utf-8 -*-


# import AVFunksjoner

# AVFunksjoner.reactivate_all_addins()
